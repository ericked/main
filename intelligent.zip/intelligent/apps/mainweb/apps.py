from django.apps import AppConfig


class MainWebConfig(AppConfig):
    name = 'apps.mainweb'
