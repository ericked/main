import datetime

from django.http import JsonResponse
from django.shortcuts import render, redirect
from DadaDemo.views.views import temper_waring
from basicweb.models import Room, Build
from datadisplay.models import Data
from datadisplay.models import Smog as Data_smog
from equipment.models import Smog as Dev_smog
from equipment.models import Device
from mainweb.models import UserForm, RegisterForm
from mainweb.models import User
from utils.sqlhelper import default, str2int, data_waring, smog


def index(request):
    dat = list(User.objects.filter(id_log=1))
    if not dat:
        dat = ''
    else:
        dat = dat[0]
    return render(request, 'main/index.html', {'data': dat})


def login(request):
    if request.method == "POST":
        login_form = UserForm(request.POST)
        message = "请检查填写的内容！"
        if login_form.is_valid():
            username = login_form.cleaned_data['username']
            password = login_form.cleaned_data['password']
            try:
                user = User.objects.get(name=username)
                if user.password == password:
                    try:
                        obj = User.objects.get(id_log=1)
                        obj.id_log = 0
                        obj.save()
                    except:
                        pass
                    user.id_log = 1
                    user.save()
                    return redirect('/main/')
                else:
                    message = "密码不正确！"
            except:
                message = "用户不存在！"
        return render(request, 'main/loginn.html', locals())
    login_form = UserForm()
    return render(request, 'main/loginn.html', locals())


def register(request):
    if request.session.get('is_login', None):
        # 登录状态不允许注册。
        return redirect("/main/")
    if request.method == "POST":
        register_form = RegisterForm(request.POST)
        message = "请检查填写的内容！"
        if register_form.is_valid():  # 获取数据
            username = register_form.cleaned_data['username']
            password1 = register_form.cleaned_data['password1']
            password2 = register_form.cleaned_data['password2']
            email = register_form.cleaned_data['email']
            sex = register_form.cleaned_data['sex']
            if password1 != password2:  # 判断两次密码是否相同
                message = "两次输入的密码不同！"
                return render(request, 'main/register.html', locals())
            else:
                same_name_user = User.objects.filter(name=username)
                if same_name_user:  # 用户名唯一
                    message = '用户已经存在，请重新选择用户名！'
                    return render(request, 'main/register.html', locals())
                same_email_user = User.objects.filter(email=email)
                if same_email_user:  # 邮箱地址唯一
                    message = '该邮箱地址已被注册，请使用其他邮箱！'
                    return render(request, 'main/register.html', locals())

                # 当一切都OK的情况下，创建新用户

                new_user = User.objects.create()
                new_user.name = username
                new_user.password = password1
                new_user.email = email
                new_user.sex = sex
                new_user.save()
                return redirect('/')  # 自动跳转到登录页面
    register_form = RegisterForm()
    return render(request, 'main/register.html', locals())


def users(request):
    return render(request, 'main/user.html')


def list_users(request):
    user = list(User.objects.all().values('name', 'email', 'sex', 'c_time', 'd_time'))
    for i in range(len(user)):
        if user[i]['sex'] == 'male':
            user[i]['sex'] = '男'
        else:
            user[i]['sex'] = '女'
        user[i]['c_time'] = default(user[i]['c_time'])
        user[i]['d_time'] = default(user[i]['d_time'])
    user = {'code': 0, 'data': user}
    return JsonResponse(user, safe=False)


def edit_user(request):
    name = request.POST
    # 修改
    try:
        obj = User.objects.get(name=name['name'])
        # 获取当前的对象
        # 逐一修改属性
        if name['sex'] == '男':
            sex = 'male'
        else:
            sex = 'female'
        obj.sex = sex
        obj.email = name['email']
        # 保存
        obj.save()
        return JsonResponse({'status': True})
    except Exception as e:
        return JsonResponse({'status': False, 'error': '修改个人信息异常，原因：' + str(e)})


def introduce(request):
    user = list(User.objects.filter(id_log=1).values('name', 'email', 'sex', 'c_time', 'd_time'))
    if user[0]['sex'] == 'male':
        user[0]['sex'] = '男'
    else:
        user[0]['sex'] = '女'
    user[0]['c_time'] = default(user[0]['c_time'])
    user[0]['d_time'] = default(user[0]['d_time'])
    return render(request, 'main/introduce.html', {'data': user})


def mains(request):
    data = []
    rooms = Room.objects.values().count()
    build = Build.objects.values()
    builds = build.count()
    for i in build:
        room = Room.objects.values().filter(build_id=i['id']).count()
        data.append({'value': room, 'name': i['name']})
    return render(request, 'main/main.html',
                  {'data': data, 'rooms': rooms, 'builds': builds})


def list_warn(request):
    e_data = []
    type_s = '正常'
    dev = []
    deveui = Device.objects.values('sno', 'build__name', 'room__name')
    now_y = int(datetime.datetime.now().strftime('%Y'))
    now_m = int(datetime.datetime.now().strftime('%m'))
    now_d = int(datetime.datetime.now().strftime('%d'))
    for i in deveui:
        new_data = Data.objects.values().filter(deveui=i['sno'], date__date=datetime.date(now_y, now_m, now_d)).last()
        if new_data is None:
            data_a = {}
            data_a['date'] = '传感器已关机'
            data_a['build'] = i['build__name']
            data_a['room'] = i['room__name']
            data_a['type'] = '错误'
            data_a['smog_type'] = ''
            data_a['message'] = '传感器' + i['sno'] + '已关机'
            e_data.append(data_a)
            continue
        if float(str2int(new_data['data'])[0]) >= 900:
            data_cell = {}
            message = '传感器' + i['sno'] + '电量不足'
            data_cell['build'] = i['build__name']
            data_cell['room'] = i['room__name']
            data_cell['type'] = '电量不足'
            data_cell['smog_type'] = ''
            data_cell['message'] = message
            e_data.append(data_cell)
        if temper_waring <= float(str2int(new_data['data'])[0]) < 900:
            type_s = '温度预警'
            message = '布控点温度过高，存在火灾风险'
            a = 10
            an = 0
            smog_type = '正常'
            now_data = list(Data.objects.values().filter(deveui=i['sno']).order_by('-id')[:a])
            end_data, m = data_waring(now_data, temper_waring)
            reserve_da = []
            while m == 1:
                an += a
                now_data = Data.objects.values().filter(deveui=i['sno']).order_by("-id")[an - a:an]
                end_data0, m = data_waring(list(now_data), temper_waring)
                if end_data0 != {}:
                    reserve_da.append(end_data0['temper'])
                    end_data['date'] = end_data0['date']
            first = end_data['temper']
            end_data['temper'] = []
            if len(reserve_da) > 0:
                reserve_da = reserve_da[::-1]
                for k in reserve_da:
                    end_data['temper'].extend(k)
            devsmog = Dev_smog.objects.values('sno', 'build__name', 'room__name')
            try:
                for ks in devsmog:
                    if ks['build__name'] == i['build__name'] and ks['room__name'] == i['room__name']:
                        dev.append(ks['sno'])
                        smog_data = Data_smog.objects.values('deveui', 'data').filter(
                            deveui__icontains=ks['sno']).last()
                        ad = smog(smog_data['data'])
                        smog_type = ad['warn']
            except:
                pass
            if type_s == '温度预警' and smog_type == '烟雾报警':
                message = '布控点温度温度过高且存在烟雾报警'
            end_data['temper'].extend(first)
            end_data['build'] = i['build__name']
            end_data['room'] = i['room__name']
            end_data['type'] = type_s
            end_data['smog_type'] = smog_type
            end_data['message'] = message
            e_data.append(end_data)  # 最后结果
    dev_s = Dev_smog.objects.values('sno', 'build__name', 'room__name')
    for de_sn in dev_s:
        ssmog = {}
        type_g = '烟雾报警'
        if de_sn['sno'] in dev:
            continue
        new_smog = Data_smog.objects.values().filter(deveui=de_sn['sno'],
                                                     date__date=datetime.date(now_y, now_m, now_d)).last()
        if new_smog is None:
            continue
        else:
            dat_stat = smog(new_smog['data'])
            if dat_stat['warn'] == '烟雾报警':
                ssmog['date'] = default(new_smog['date'])
                waring = '存在烟雾报警，请检查该区域情况，谨防火灾'
            elif dat_stat['cell_status'] == '电量低':
                ssmog['date'] = default(new_smog['date'])
                type_g = '正常'
                waring = '电量低'
            else:
                continue
        ssmog['build'] = de_sn['build__name']
        ssmog['room'] = de_sn['room__name']
        ssmog['type'] = type_s
        ssmog['smog_type'] = type_g
        ssmog['message'] = '传感器' + de_sn['sno'] + waring
        e_data.append(ssmog)
    for i in range(len(e_data)):
        a = []
        b = []
        if 'temper' in e_data[i]:
            first_data = e_data[i]['temper']
            e_data[i]['temper'] = []
            for d in first_data:
                a.append(d['date'])
                b.append(d['data'])
            e_data[i]['temper'].append(a)
            e_data[i]['temper'].append(b)
    res = {'code': 0, 'data': e_data}
    return JsonResponse(res)
