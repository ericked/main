from django.urls import path
from mainweb import views as main_views

urlpatterns = [
    path('main/', main_views.index, name="main"),
    path('', main_views.login, name="login"),
    path('register/', main_views.register, name="register"),
    path('users/', main_views.users, name='users'),
    path('users_list/', main_views.list_users, name='users_list'),
    path('edit_user/', main_views.edit_user, name='edit_user'),
    path('introduce/', main_views.introduce, name='introduce'),
    path('mains/', main_views.mains, name='mains'),
    path('list_warn/', main_views.list_warn, name='list_warn')
]
