import datetime
import random

from django.http import JsonResponse
from django.shortcuts import render
from DadaDemo.views.views import temper_waring
from datadisplay.models import Data
from equipment.models import Device
from datadisplay.models import Smog as Data_smog
from equipment.models import Smog as Dev_smog
from utils import sqlhelper
from utils.sqlhelper import smog


def warn_show(request):
    return render(request, 'data/warn_show.html')


def smog_show(request):
    return render(request, 'data/smog_show.html')


def warn_shows(request):
    itemStyle = {
        'opacity': 0.8,
        'shadowBlur': 10,
        'shadowOffsetX': 0,
        'shadowOffsetY': 0,
        'shadowColor': 'rgba(0,0,0,0.3)'
    }
    data = {}
    data_name = []
    data_end = []
    deveui = Device.objects.all()
    try:
        New_data = list(Data.objects.values().order_by('-id')[:50])
    except:
        New_data = list(Data.objects.values().order_by('-id').all())
    for i in New_data:
        if float(sqlhelper.str2int(i['data'])[0]) >= temper_waring:
            time = i['date']
            try:
                data[i['deveui']].append(
                    [time,
                     float(sqlhelper.str2int(i['data'])[0]), float(sqlhelper.str2int(i['data'])[1]),
                     '异常'])
            except:
                data[i['deveui']] = [
                    [time, float(sqlhelper.str2int(i['data'])[0]),
                     float(sqlhelper.str2int(i['data'])[1]), '异常']]
    for j in deveui:
        j = str(j)
        try:
            valued = Device.objects.filter(sno=j).values('build__name', 'room__name')
            names = valued[0]['build__name'] + '.' + valued[0]['room__name']
            data_end.append({'name': names, 'type': 'scatter', 'itemStyle': itemStyle, 'data': data[j]})
            data_name.append(names)
        except:
            pass
    data_end = {'name': data_name, 'data': data_end}
    return JsonResponse(data_end, safe=False)


def smog_shows(request):
    itemStyle = {
        'opacity': 0.8,
        'shadowBlur': 10,
        'shadowOffsetX': 0,
        'shadowOffsetY': 0,
        'shadowColor': 'rgba(0,0,0,0.3)'
    }
    build_name = []
    smog_data = []
    now_y = int(datetime.datetime.now().strftime('%Y'))
    now_m = int(datetime.datetime.now().strftime('%m'))
    now_d = int(datetime.datetime.now().strftime('%d'))
    smog_dev = list(Dev_smog.objects.values('sno', 'build__name', 'room__name'))
    for data in smog_dev:
        smog_d = []
        name = data['build__name'] + '.' + data['room__name']
        smog_first = list(Data_smog.objects.values().filter(deveui=data['sno'],
                                                            date__date=datetime.date(now_y, now_m, now_d)).all())
        for sd in smog_first:
            if smog(sd['data'])['warn'] == '烟雾报警':
                build_name.append(name)
                if sd['ranges'] is None:
                    obj = Data_smog.objects.get(id=sd['id'])
                    a = random.uniform(0.65, 8.5)
                    obj.ranges = a
                    sd['range'] = a
                    obj.save()
                smog_d.append([sd['date'], sd['ranges'], '烟雾报警'])
        if len(smog_d) > 0:
            smog_data.append(
                {'name': name, 'type': 'scatter', 'itemStyle': itemStyle, 'data': smog_d, 'symbolSize': 40})
    data_end = {'name': build_name, 'data': smog_data}
    return JsonResponse(data_end, safe=False)
