from django.db.models import Q
from django.shortcuts import render
from DadaDemo.views.views import temper_waring
from datadisplay.models import Data
from datadisplay.models import Smog as Smog_data
from equipment.models import Smog as Dev_smog
from equipment.models import Device
from utils import sqlhelper
from django.http import JsonResponse


def index(request):
    return render(request, 'data/data.html')


def index2(request):
    return render(request, 'data/smog.html')


def list_smog(request):
    dev_name = request.POST.get('dev_name')
    dn_build = request.POST.get('dn_build')
    dn_room = request.POST.get('dn_room')
    first_data = Smog_data.objects.filter(Q(deveui__icontains=dev_name))
    if len(dn_build) > 0:
        dev_nd = ''
        first0_data = Dev_smog.objects.filter(build_id=dn_build)
        for i in first0_data:
            i = str(i)
            if dev_nd != '':
                dev_nd += ' | '
            dev_nd += 'Q(deveui__icontains=\'' + i + '\')'
        first_data = first_data.filter(eval(dev_nd))
    if len(dn_room) > 0:
        dev_nd = ''
        first0_data = Dev_smog.objects.filter(room__id=dn_room)
        for i in first0_data:
            i = str(i)
            if dev_nd != '':
                dev_nd += ' | '
            dev_nd += 'Q(deveui__icontains=\'' + i + '\')'
        first_data = first_data.filter(eval(dev_nd))
    page = int(request.POST.get('page', 0))
    limit = int(request.POST.get('limit', 0))
    count = first_data.all().count()
    d1 = list(first_data.values().order_by('-id')[(page - 1) * limit:page * limit + 1])
    d2 = list(Dev_smog.objects.values('sno', 'build__name', 'room__name', 'gateway__name'))
    dat = []
    for i in d1:
        for j in d2:
            if i['deveui'] == j['sno']:
                date = sqlhelper.default(i['date'])
                data = sqlhelper.smog(i['data'])
                dat.append({'deveui': i['deveui'], 'build_name': j['build__name'], 'room_name': j['room__name'],
                            'date': date, 'warn': data['warn'], 'smog_status': data['smog_status'],
                            'cell_status': data['cell_status'], 'key_status': data['key_status']})
    res = {'code': 0, 'count': count, 'data': dat}
    return JsonResponse(res, safe=False)


def list_dd(request):
    dev_name = request.POST.get('dev_name')
    dn_build = request.POST.get('dn_build')
    dn_room = request.POST.get('dn_room')
    first_data = Data.objects.filter(Q(deveui__icontains=dev_name))
    if len(dn_build) > 0:
        dev_nd = ''
        first0_data = Device.objects.filter(build_id=dn_build)
        for i in first0_data:
            i = str(i)
            if dev_nd != '':
                dev_nd += ' | '
            dev_nd += 'Q(deveui__icontains=\'' + i + '\')'
        first_data = first_data.filter(eval(dev_nd))
    if len(dn_room) > 0:
        dev_nd = ''
        first0_data = Device.objects.filter(room__id=dn_room)
        for i in first0_data:
            i = str(i)
            if dev_nd != '':
                dev_nd += ' | '
            dev_nd += 'Q(deveui__icontains=\'' + i + '\')'
        first_data = first_data.filter(eval(dev_nd))
    # 获取分页page和limit
    page = int(request.POST.get('page', 0))
    limit = int(request.POST.get('limit', 0))
    count = first_data.all().count()
    d1 = list(first_data.values().order_by('-id')[(page - 1) * limit:page * limit + 1])
    d2 = list(Device.objects.values('sno', 'build__name', 'room__name', 'gateway__name'))
    dat = []
    if page != 0 and limit != 0:
        for i in range(len(d1)):
            a = b = c = ''
            ti = waring = ''
            for j in range(len(d2)):
                if d2[j]['sno'] == d1[i]['deveui']:
                    a = d2[j]['build__name']
                    b = d2[j]['room__name']
                    c = d2[j]['gateway__name']
                    ti = sqlhelper.str2int(d1[i]['data'])[0]
                    if float(ti) > temper_waring:
                        waring = '异常'
                    else:
                        waring = '正常'
            dat.append({'deveui': d1[i]['deveui'], 'build_name': a, 'room_name': b, 'gateway': c,
                        'date': sqlhelper.default(d1[i]['date']),
                        'temper': ti + ' ℃',
                        'shidu': sqlhelper.str2int(d1[i]['data'])[1] + ' %',
                        'waring': waring})
    res = {'code': 0, 'count': count, 'data': dat}
    return JsonResponse(res, safe=False)


def search_room(request):
    try:
        objs = list(Device.objects.values('room_id', 'room__name'))
        return JsonResponse({'status': True, 'data': objs})
    except Exception as e:
        return JsonResponse({'status': False, 'error': "获取布控点数据出现异常，具体原因：" + str(e)})


def search_build(request):
    try:
        objs = list(Device.objects.values('build_id', 'build__name'))
        return JsonResponse({'status': True, 'data': objs})
    except Exception as e:
        return JsonResponse({'status': False, 'error': "获取布控点数据出现异常，具体原因：" + str(e)})


def search_values(request):
    if request.POST.get('id'):
        d_sno = request.POST.get('id')
        try:
            objs = list(Device.objects.filter(build_id=d_sno).values('room_id', 'room__name'))
            return JsonResponse({'status': True, 'data': objs})
        except Exception as e:
            return JsonResponse({'status': False, 'error': "获取布控点数据出现异常，具体原因：" + str(e)})
    else:
        try:
            objs = list(Device.objects.filter().values('room_id', 'room__name'))
            return JsonResponse({'status': True, 'data': objs})
        except Exception as e:
            return JsonResponse({'status': False, 'error': "获取布控点数据出现异常，具体原因：" + str(e)})
