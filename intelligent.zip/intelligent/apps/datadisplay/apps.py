from django.apps import AppConfig


class DatawebConfig(AppConfig):
    name = 'apps.datadisplay'
