from django.db import models


class Data(models.Model):
    id = models.AutoField(primary_key=True)
    data = models.CharField(verbose_name='模组数据', max_length=100)
    date = models.DateTimeField(verbose_name='时间')
    deveui = models.CharField(verbose_name='模组EUI', max_length=100)

    class Meta:
        managed = True
        app_label = "datadisplay"
        db_table = "reserve"
        verbose_name = "Date"
        verbose_name_plural = "Date"

    def __str__(self):
        return '%s' % self.deveui


class Smog(models.Model):
    id = models.AutoField(primary_key=True)
    data = models.CharField(verbose_name='模组数据', max_length=100)
    date = models.DateTimeField(verbose_name='时间')
    deveui = models.CharField(verbose_name='模组EUI', max_length=100)
    ranges = models.FloatField(null=True)

    class Meta:
        managed = True
        app_label = "datadisplay"
        db_table = "smog"
        verbose_name = "Date"
        verbose_name_plural = "Date"

    def __str__(self):
        return '%s' % self.deveui
