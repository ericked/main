from django.urls import path
from datadisplay.views import data, warn

urlpatterns = [
    path('', data.index, name="data_list"),
    path('smog/', data.index2, name="smog"),
    path('list/', data.list_dd, name="data_show"),
    path('s_room/', data.search_room, name='search_room'),
    path('s_build/', data.search_build, name='search_build'),
    path('ss_room/', data.search_values, name='search_rooms'),
    path('warn_show/', warn.warn_show, name='warn_show'),
    path('waring_show/', warn.warn_shows, name='waring_show'),
    path('l_smog/', data.list_smog, name="l_smog"),
    path('smog_show/', warn.smog_show, name='smog_show'),
    path('smog_shows/', warn.smog_shows, name='smog_shows')
]
