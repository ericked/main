import datetime
from django.conf import settings
import psycopg2


def conn_db():
    # 定义一个返回值的结构体
    res = {}
    # 使用异常处理连接
    try:
        # 实例化一个连接对象
        conn = psycopg2.connect(host=settings.DATABASES['default']['HOST'], user=settings.DATABASES['default']['USER'],
                                password=settings.DATABASES['default']['PASSWORD'],
                                database=settings.DATABASES['default']['NAME'])

        # 添加连接的状态值
        res['status'] = True
        # 添加连接的对象
        res['conn'] = conn

    except Exception as e:
        # 添加连接的状态值
        res['status'] = False
        # 添加连接错误的信息
        res['error'] = '连接数据库出现异常！具体原因：' + str(e)

    # 返回
    return res  #


def get_db_data(sql: str):
    """
    根据提供的SQL语句，连接数据库查询，返回查询后的结果
    :param sql: 提供的SQL语句
    :return: 返回的数据
    """
    # 获取一个数据库的连接
    rec = conn_db()
    # 判断是否连接成功

    if not rec['status']:
        return rec
    # 获取一个操作数据库的指针
    cursor = rec['conn'].cursor()

    # 使用异常处理执行语句
    try:
        # 执行获取的传递的SQL语句
        cursor.execute(sql)
        # 获取返回的结果
        rec['data'] = cursor.fetchall()
        # 添加一个错误key
        rec['error'] = ""
    except Exception as e:
        # 修改执行的状态
        rec['status'] = False
        # 添加错误信息
        rec['error'] = '获取数据库数据出现异常！具体原因：' + str(e)
    # 返回
    return rec


def update_db(sql: str):
    """
    实现对数据库的修改：修改（Update、Insert、Delete）
    :param sql: 提供SQL语句
    :return: 返回执行的结果
    """
    # 获取连接数据库的对象
    rec = conn_db()
    # 判断是否连接成功

    if not rec['status']:
        return rec
    # 获取一个操作数据库的指针
    cursor = rec['conn'].cursor()

    # 使用异常处理执行SQL语句并提交到数据库
    try:
        # 执行SQL语句
        cursor.execute(sql)
        # 把修改提交到数据库
        rec['conn'].commit()
        # 添加一个错误key
        rec['error'] = ""
    except Exception as e:
        # 修改执行的状态
        rec['status'] = False
        # 回滚操作
        rec['conn'].rollback()
        # 修改数据库的错误信息题库
        rec['error'] = "修改数据库出现异常！具体原因：" + str(e)
    # 返回
    return rec


def bluk_insert(sql: str, data: list):
    """
    批量插入数据
    :param sql: SQL语句的模板
    :param data: 提供的数据集合
    :return: 返回结果
    """
    # 获取连接数据库的对象
    rec = conn_db()
    # 判断是否连接成功
    if not rec['status']:
        return rec
    # 获取一个操作数据库的指针
    cursor = rec['conn'].cursor()

    # 使用异常处理执行SQL语句并提交到数据库
    try:
        # 执行SQL语句
        cursor.executemany(sql, data)
        # 把修改提交到数据库
        rec['conn'].commit()

        # 添加一个错误key
        rec['error'] = ""
    except Exception as e:
        # 修改执行的状态
        rec['status'] = False
        # 回滚操作
        rec['conn'].rollback()
        # 修改数据库的错误信息题库
        rec['error'] = "修改数据库出现异常！具体原因：" + str(e)
    # 返回
    return rec


def get_db_data_dict(sql, keys: list):
    """
    获取数据，并转为Dict的格式
    :param sql: 提供的SQL语句
    :param keys: dict的key
    :return: 返回数据的格式 -- [{}，{}，{}，{}，{}，]
    """
    # 调用数据库获取数据
    response = get_db_data(sql)
    # 判断是否成功
    if not response['status']:
        return response
    # 拼接成字典
    data = []
    # 循环
    for index, value in enumerate(response['data']):
        # 定义一个dict
        temp_dict = {}
        # 遍历
        for i, v in enumerate(value):
            temp_dict[keys[i]] = v
        # 附加到集合
        data.append(temp_dict)
    # 修改携带的数据
    response['data'] = data
    # 返回
    return response


def str2int(bn):  # 数据转换
    data = []
    dat = []
    bn = bn.split()
    lens = len(bn) // 4
    for i in range(lens):
        if lens > 2:
            dat.append(''.join(bn[i * 4:i * 4 + 4:]))  # 大端数据
        else:
            dat.append((''.join(bn[::-1]))[(i - 1) * 8:-(i - 1) * 8 + 8:])  # 小端数据
    for h in range(lens):
        bn0 = dat[h]
        bn0 = bin(eval('0x' + bn0))
        bn0 = bn0[2::]
        if len(bn0) < 32:
            bn0 = "0" * (32 - len(bn0)) + bn0
        an = bn0[0]  # 符号位
        dn = bn0[9::]  # 尾码
        a = '0b' + bn0[1:9:]  # 阶码
        number1 = number2 = number0 = 0
        if eval(a) - 127 < 0:
            nun1 = '0' * (abs(127 - eval(a)) - 1) + '1' + dn
            for i in range(len(nun1)):
                number0 += eval(nun1[i]) * 2 ** (-(i + 1))
        else:
            if eval(a) - 127 > len(dn):
                dn = '1' + dn + '0' * (eval(a) - 127 - len(dn))
            else:
                dn = '1' + dn
            x = (dn[:abs(127 - eval(a)) + 1:])[::-1]
            y = dn[abs(127 - eval(a)) + 1::]
            for i in range(len(y)):
                number1 += eval(y[i]) * 2 ** (-(i + 1))
            for i in range(len(x)):
                number2 += eval(x[i]) * 2 ** i
            number0 = number1 + number2
        number0 = round(number0, 2)
        nums = ''
        if an == '0':
            nums = str(number0)
        if an == '1':
            nums = '-' + str(number0)
        data.append(nums)
    return data


def default(obj):
    if isinstance(obj, datetime.datetime):
        return obj.strftime('%Y-%m-%d %H:%M:%S')
    elif isinstance(obj, datetime.date):
        return obj.strftime("%Y-%m-%d")
    else:
        return obj


def defaults(obj):
    if isinstance(obj, datetime.datetime):
        return obj.strftime('%Y-%m-%d')
    elif isinstance(obj, datetime.date):
        return obj.strftime("%Y-%m-%d")
    else:
        return obj


def data_waring(obj, tempers):
    # obj形式为[{'deveui': '363437470e29003a', 'temper': '21.14', 'shidu': '34.43 %', 'date': '2021-04-18 16:49:14'}]
    m = 0
    aa = []
    m_data = {}
    for data in obj:
        if float(str2int(data['data'])[0]) >= tempers:
            aa.append({'date': default(data['date']), 'data': float(str2int(data['data'])[0])})
            if data == obj[-1]:
                m = 1
                date_ed = aa[-1]['date']
                aa = aa[::-1]
                m_data = {'deveui': data['deveui'], 'temper': aa, 'date': date_ed}
        else:
            if len(aa) == 0:
                continue
            else:
                date_ed = aa[-1]['date']
                aa = aa[::-1]
                m_data = {'deveui': data['deveui'], 'temper': aa, 'date': date_ed}
            break
    return m_data, m


# m_data 形式为{'temper': [{'date': '2021-04-18 16:49:14', 'data': 21.14},
# {'date': '2021-04-18 16:49:22', 'data': 21.15}, {'date': '2021-04-18 16:49:24', 'data': 21.15}],
# 'date': '2021-04-18 16:49:14','deveui':'13546486451'}


def smog(obj):
    obj = obj.replace(' ', '')
    if len(obj) < 8:
        data = {'warn': '正常', 'smog_status': '开机', 'cell_status': '开机', 'dis_status': '正常',
                'key_status': '正常'}
        return data
    warn_data = obj[4:6]
    status_data = obj[6:8]
    if warn_data == '00':
        warn = '正常'
    elif warn_data == '04':
        warn = '烟雾报警'
    else:
        warn = '错误'
    status = ''
    for i in range(2):
        a = str(bin(eval('0x' + status_data[i])))
        if len(a) <= 6:
            a = a[2:]
            a = '0' * (4 - len(a)) + a
        else:
            a = a[:4]
        status += a
    smog_data = status[:2]
    cell_data = status[2:4]
    dis_data = status[4]
    key_data = status[5:]
    if smog_data == '00':
        smog_status = '正常'
    elif smog_data == '01':
        smog_status = '传感器故障'
    else:
        smog_status = '数据解析错误'
    if cell_data == '00':
        cell_status = '正常'
    elif cell_data == '01':
        cell_status = '电量低'
    else:
        cell_status = '数据解析错误'
    if dis_data == '0':
        dis_status = '正常'
    else:
        dis_status = '被拆'
    if key_data == '000':
        key_status = '正常'
    elif key_data == '001':
        key_status = '测试'
    elif key_data == '010':
        key_status = '消音'
    else:
        key_status = '数据解析错误'
    data = {'warn': warn, 'smog_status': smog_status, 'cell_status': cell_status, 'dis_status': dis_status,
            'key_status': key_status}
    return data
