from django.db import models
from basicweb.models import Build, Room


class Gateway(models.Model):
    name = models.CharField(verbose_name='网关名称', max_length=100, unique=True, null=False)

    class Meta:
        managed = True
        app_label = "equipment"
        db_table = "gateway"
        verbose_name = "gateway"
        verbose_name_plural = "gateway"

    def __str__(self):
        return '%s' % self.name


class D_ipv6(models.Model):
    D_ipv6 = models.CharField(verbose_name='网关ip', max_length=100, unique=True, null=False)
    name = models.ForeignKey(verbose_name='网关名称', to=Gateway, on_delete=models.PROTECT)

    class Meta:
        managed = True
        app_label = "equipment"
        db_table = "d_ipv6"
        verbose_name = "d_ipv6"
        verbose_name_plural = "d_ipv6"

    def __str__(self):
        return '%s' % self.D_ipv6


class Device(models.Model):
    sno = models.CharField(verbose_name='模组EUI', max_length=100)
    S_ipv6 = models.CharField(verbose_name='ChirpStack_IP', max_length=100)
    D_ipv6 = models.ForeignKey(verbose_name='网关ip', to=D_ipv6, on_delete=models.PROTECT)
    gateway = models.ForeignKey(verbose_name='网关名称', to=Gateway, on_delete=models.PROTECT)
    build = models.ForeignKey(verbose_name='所属楼宇', to=Build, on_delete=models.PROTECT)
    room = models.ForeignKey(verbose_name='所属布控点', to=Room, on_delete=models.PROTECT)
    start_date = models.DateTimeField(verbose_name='上线时间')
    status = models.CharField(verbose_name='状态', max_length=100, choices=(
        ('在线', '在线'), ('断开', '断开')), default='在线')

    class Meta:
        managed = True
        app_label = 'equipment'
        db_table = "loramode"
        verbose_name = "loramode"
        verbose_name_plural = "loramode"

    def __str__(self):
        return "%s" % self.sno


class Smog(models.Model):
    sno = models.CharField(verbose_name='模组EUI', max_length=100)
    S_ipv6 = models.CharField(verbose_name='ChirpStack_IP', max_length=100)
    D_ipv6 = models.ForeignKey(verbose_name='网关ip', to=D_ipv6, on_delete=models.PROTECT)
    gateway = models.ForeignKey(verbose_name='网关名称', to=Gateway, on_delete=models.PROTECT)
    build = models.ForeignKey(verbose_name='所属楼宇', to=Build, on_delete=models.PROTECT)
    room = models.ForeignKey(verbose_name='所属布控点', to=Room, on_delete=models.PROTECT)
    start_date = models.DateTimeField(verbose_name='上线时间')

    class Meta:
        managed = True
        app_label = 'equipment'
        db_table = "dev_smog"
        verbose_name = "smog"
        verbose_name_plural = "smog"

    def __str__(self):
        return "%s" % self.sno
