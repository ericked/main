from django.urls import path
from equipment.views import gateway, equip, smog

urlpatterns = [
    path('', equip.index, name="lora"),
    path('list/', equip.list_values, name="list_value"),
    path('lora/', equip.query_values, name="query_values"),
    path('loral/', equip.query_value, name="query_value"),
    path('add/', equip.add_value, name="add_value"),
    path('del/', equip.del_value, name="del_value"),
    path('edit/', equip.edit_value, name='edit_value'),
    path('is/', equip.is_sno, name='is_sno'),
    path('way/', gateway.index, name='way'),
    path('l_way/', gateway.list_way, name='l_way'),
    path('a_way/', gateway.add_way, name='a_way'),
    path('del_way/', gateway.del_way, name='del_way'),
    path('is_way/', gateway.is_way, name='is_way'),
    path('ed_way/', gateway.edit_way, name='ed_way'),
    path('list_way/', gateway.lis_way, name='list_way'),
    path('smog/', smog.index, name="in_smog"),
    path('list_smog/', smog.list_values, name="list_smog"),
    path('add_smog/', smog.add_value, name="add_smog"),
    path('edit_smog/', smog.edit_value, name="edit_smog"),
    path('is_smog/', smog.is_sno, name="is_smog"),
    path('del_smog/', smog.del_value, name="del_smog")
]
