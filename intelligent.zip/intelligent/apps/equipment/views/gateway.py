from django.db.models import Q
from django.http import JsonResponse
from django.shortcuts import render
from equipment.models import D_ipv6, Gateway


def index(request):
    return render(request, 'equip/gateway.html')


def list_way(request):
    page = int(request.POST.get('page', 0))
    limit = int(request.POST.get('limit', 0))
    d_sno = request.POST.get('q_sno_name')
    filter_data = D_ipv6.objects.filter(
        Q(D_ipv6__icontains=d_sno) | Q(name__name__icontains=d_sno))
    objs = list(filter_data.values('D_ipv6', 'name__name').all())
    res = {'count': len(objs), 'code': 0, 'data': objs}
    if page != 0 and limit != 0:
        one_page = objs[(page - 1) * limit:page * limit]
        res['data'] = one_page
    return JsonResponse(res)


def lis_way(request):
    objs = list(D_ipv6.objects.values('id', 'name__name').all())
    res = {'status': True, 'data': objs}
    return JsonResponse(res)


def add_way(request):
    rec = request.POST
    print(rec)
    try:
        Gateway.objects.create(name=rec['name__name'])
        D_ipv6.objects.create(D_ipv6=rec['D_ipv6'],
                              name=Gateway.objects.get(name=rec['name__name']))
        return JsonResponse({'status': True})
    except Exception as e:
        try:
            Gateway.objects.get(name=rec['name__name']).delete()
        except:
            pass
        return JsonResponse({'status': False, 'error': "添加网关失败，原因:" + str(e)})


def del_way(request):
    gateway = request.POST.get('gateway')
    d_ipv6 = request.POST.get('D_ipv6')
    # 修改
    try:
        # 获取当前的对象并删除
        D_ipv6.objects.get(D_ipv6=d_ipv6).delete()
        Gateway.objects.get(name=gateway).delete()
        return JsonResponse({'status': True})
    except Exception as e:
        return JsonResponse({'status': False, 'error': '修改信息提交到数据库出现异常，具体原因：' + str(e)})


def is_way(request):
    """校验EUI是否存在"""
    # 获取EUI
    gateway = request.POST.get('gateway')
    # 判断
    iss = Gateway.objects.filter(name=gateway).exists()
    # 返回
    return JsonResponse({'data': iss})


def edit_way(request):
    # 接收传递的值
    rec = request.POST
    # 修改
    try:
        # 获取当前的对象
        obj = D_ipv6.objects.get(D_ipv6=rec['D_ipv6'])
        # 逐一修改属性
        obj.D_ipv6 = rec['D_ipv6']
        # 保存
        obj.save()
        return JsonResponse({'status': True})
    except Exception as e:
        return JsonResponse({'status': False, 'error': '修改信息提交到数据库出现异常，具体原因：' + str(e)})
