from django.db.models import Q
from django.http import JsonResponse
from django.shortcuts import render
from basicweb.models import Build, Room
from equipment.models import Smog, D_ipv6, Gateway
from utils.sqlhelper import defaults


def index(request):
    return render(request, 'equip/smog.html')


def list_values(request):
    page = int(request.POST.get('page', 0))
    limit = int(request.POST.get('limit', 0))
    d_sno = request.POST.get('q_sno_name')
    d_build = request.POST.get('d_build')
    d_room = request.POST.get('d_room')
    filter_data = Smog.objects.filter(
        Q(sno__icontains=d_sno) | Q(S_ipv6__icontains=d_sno) | Q(D_ipv6__D_ipv6__icontains=d_sno) | Q(
            gateway__name__icontains=d_sno) | Q(
            build__name__icontains=d_sno) | Q(room__name__icontains=d_sno) | Q(
            start_date__icontains=d_sno)
    )
    if len(d_build) > 0:
        filter_data = filter_data.filter(build_id=d_build)
    if len(d_room) > 0:
        filter_data = filter_data.filter(room_id=d_room)
    objs = list(
        filter_data.values('sno', 'S_ipv6', 'D_ipv6__D_ipv6', 'gateway__name', 'start_date', 'build__name',
                           'room__name'))
    for i in range(len(objs)):
        objs[i]['start_date'] = defaults(objs[i]['start_date'])
    res = {'code': 0, 'count': len(objs), 'data': objs}
    if page != 0 and limit != 0:
        one_page = objs[(page - 1) * limit:page * limit]
        res['data'] = one_page
    return JsonResponse(res)


def add_value(request):
    rec = request.POST
    try:
        d_ipv6 = list(D_ipv6.objects.filter(name__name=rec['gateway__name']).values('D_ipv6'))
        Smog.objects.create(sno=rec['sno'], S_ipv6=rec['S_ipv6'],
                            D_ipv6=D_ipv6.objects.get(D_ipv6=d_ipv6[0]['D_ipv6']),
                            gateway=Gateway.objects.get(name=rec['gateway__name']),
                            start_date=rec['start_date'],
                            build=Build.objects.get(id=rec['build']), room=Room.objects.get(id=rec['room']))
        return JsonResponse({'status': True})
    except Exception as e:
        return JsonResponse({'status': False, 'error': "添加终端失败，原因:" + str(e)})


# 修改
def edit_value(request):
    # 接收传递的值
    rec = request.POST
    # 修改
    try:
        # 获取当前的对象
        d_ipv6 = list(D_ipv6.objects.filter(name__name=rec['gateway__name']).values('D_ipv6'))
        obj = Smog.objects.get(sno=rec['sno'])
        # 逐一修改属性
        obj.S_ipv6 = rec['S_ipv6']
        obj.D_ipv6 = D_ipv6.objects.get(D_ipv6=d_ipv6[0]['D_ipv6'])
        obj.gateway = Gateway.objects.get(name=rec['gateway__name'])
        obj.build = Build.objects.get(id=rec['build'])
        obj.room = Room.objects.get(id=rec['room'])
        obj.start_date = rec['start_date']
        # 保存
        obj.save()
        return JsonResponse({'status': True})
    except Exception as e:
        return JsonResponse({'status': False, 'error': '修改信息提交到数据库出现异常，具体原因：' + str(e)})


def is_sno(request):
    """校验EUI是否存在"""
    # 获取EUI
    sno = request.POST.get('sno')
    # 判断
    iss = Smog.objects.filter(sno=sno).exists()
    # 返回
    return JsonResponse({'data': iss})


def del_value(request):
    # 接收传递的值
    sno = request.POST.get('sno')
    # 修改
    try:
        # 获取当前的对象并删除
        Smog.objects.get(sno=sno).delete()
        return JsonResponse({'status': True})
    except Exception as e:
        return JsonResponse({'status': False, 'error': '修改信息提交到数据库出现异常，具体原因：' + str(e)})
