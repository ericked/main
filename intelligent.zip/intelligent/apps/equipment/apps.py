from django.apps import AppConfig


class EquipmentConfig(AppConfig):
    name = 'apps.equipment'
