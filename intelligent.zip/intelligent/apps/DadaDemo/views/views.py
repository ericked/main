import json
from django.db.models import Q
from django.http import HttpResponse
from django.shortcuts import render
from rest_framework.views import APIView

from pyecharts.charts import Line
from pyecharts import options as opts

from datadisplay.models import Data
from equipment.models import Device
from utils import sqlhelper

temper_waring = 30
shi_waring = 35


def response_as_json(data):
    json_str = json.dumps(data)
    response = HttpResponse(
        json_str,
        content_type="application/json",
    )
    response["Access-Control-Allow-Origin"] = "*"
    return response


def json_response(data, code=200):
    data = {
        "code": code,
        "msg": "success",
        "data": data,
    }
    return response_as_json(data)


def json_error(error_string="error", code=500, **kwargs):
    data = {
        "code": code,
        "msg": error_string,
        "data": {}
    }
    data.update(kwargs)
    return response_as_json(data)


JsonResponse = json_response
JsonError = json_error


def line_base(name):
    a = []
    b = []
    new_data = (Data.objects.filter(Q(deveui__icontains=name)).values().order_by("-id")[:25])[::-1]
    for i in range(len(new_data)):
        a.append(sqlhelper.default(new_data[i]['date']))
        b.append(sqlhelper.str2int(new_data[i]['data'])[0])
    valued = Device.objects.filter(sno=name).values('build__name', 'room__name')
    names = valued[0]['room__name'] + '--' + valued[0]['build__name'] + '(' + name + ')'
    line = (
        Line()
            .add_xaxis(a)
            .add_yaxis(series_name="温度 ℃", y_axis=b, is_smooth=True, is_connect_nones=True,
                       areastyle_opts=opts.AreaStyleOpts(opacity=0.5))
            .set_global_opts(
            visualmap_opts=opts.VisualMapOpts(is_piecewise=True, pieces=[{'max': temper_waring, 'color': 'rgb(156,'
                                                                                                         '209,231)'},
                                                                         {'min': temper_waring, 'max': 50,
                                                                          'color': 'rgb(177,217,158)'},
                                                                         {'min': 50, 'color': 'red'}]),
            title_opts=opts.TitleOpts(title=names),
            xaxis_opts=opts.AxisOpts(type_="category"),
            yaxis_opts=opts.AxisOpts(type_="value", is_scale=True),
            tooltip_opts=opts.TooltipOpts(is_show=True, axis_pointer_type="line", trigger="axis"),
            datazoom_opts=opts.DataZoomOpts(range_start=0, range_end=100),
            toolbox_opts=opts.ToolboxOpts(is_show=True,
                                          pos_top="top",
                                          pos_left="right",
                                          feature={"saveAsImage": {},
                                                   "restore": {},
                                                   "dataView": {}}))
            .set_series_opts(
            markline_opts=opts.MarkLineOpts(
                data=[
                    opts.MarkLineItem(
                        name="温度预警",
                        y=temper_waring,
                    )],
                label_opts=opts.LabelOpts(is_show=True),
                linestyle_opts=opts.LineStyleOpts(type_="dotted", width=3, color='#FF0000')
            )
        )
            .dump_options_with_quotes()
    )
    return line


class ChartView0(APIView):
    def get(self, request, *args, **kwargs):
        line = {}
        counts = Device.objects.values('sno')
        for i in counts:
            line[i['sno']] = json.loads(line_base(i['sno']))
        return JsonResponse(line)


def shi_line(name):
    a = []
    b = []
    new_data = (Data.objects.filter(Q(deveui__icontains=name)).values().order_by("-id")[:25])[::-1]
    for i in range(len(new_data)):
        a.append(sqlhelper.default(new_data[i]['date']))
        b.append(sqlhelper.str2int(new_data[i]['data'])[1])
    valued = Device.objects.filter(sno=name).values('build__name', 'room__name')
    names = valued[0]['room__name'] + '--' + valued[0]['build__name'] + '(' + name + ')'
    line = (
        Line()
            .add_xaxis(a)
            .add_yaxis(series_name="湿度 %", y_axis=b, is_smooth=True, is_connect_nones=True,
                       areastyle_opts=opts.AreaStyleOpts(opacity=0.5))
            .set_global_opts(
            visualmap_opts=opts.VisualMapOpts(is_piecewise=True,
                                              pieces=[{'max': shi_waring, 'color': 'red'},
                                                      {'min': shi_waring, 'max': 65,
                                                       'color': 'rgb(177,217,158)'},
                                                      {'min': 65, 'color': 'rgb(144,202,117)'}]),
            title_opts=opts.TitleOpts(title=names),
            xaxis_opts=opts.AxisOpts(type_="category"),
            yaxis_opts=opts.AxisOpts(type_="value", is_scale=True),
            tooltip_opts=opts.TooltipOpts(is_show=True, axis_pointer_type="line", trigger="axis"),
            datazoom_opts=opts.DataZoomOpts(range_start=0, range_end=100),
            toolbox_opts=opts.ToolboxOpts(is_show=True,
                                          pos_top="top",
                                          pos_left="right",
                                          feature={"saveAsImage": {},
                                                   "restore": {},
                                                   "dataView": {}}))
            .set_series_opts(
            markline_opts=opts.MarkLineOpts(
                data=[
                    opts.MarkLineItem(
                        name="湿度预警",
                        y=shi_waring,
                    )],
                label_opts=opts.LabelOpts(is_show=True),
                linestyle_opts=opts.LineStyleOpts(type_="dotted", width=3, color='#FF0000')
            )
        )
            .dump_options_with_quotes()
    )
    return line


class ChartView1(APIView):
    def get(self, request, *args, **kwargs):
        line = {}
        counts = Device.objects.values('sno')
        for i in counts:
            line[i['sno']] = json.loads(shi_line(i['sno']))
        return JsonResponse(line)


class IndexView(APIView):
    def get(self, request, *args, **kwargs):
        return render(request, 'demoshow.html')


class IndexView0(APIView):
    def get(self, request, *args, **kwargs):
        return render(request, 'demoshows.html')


def indst(request):
    e = ''
    line = {}
    dev_name = request.POST.get('dev_name')
    dn_build = request.POST.get('dn_build')
    dn_room = request.POST.get('dn_room')
    counts = Device.objects.filter(Q(sno__icontains=dev_name))
    if len(dn_build) > 0:
        dev_nd = ''
        first0_data = Device.objects.filter(build_id=dn_build)
        for i in first0_data:
            i = str(i)
            if dev_nd != '':
                dev_nd += ' | '
            dev_nd += 'Q(sno__icontains=\'' + i + '\')'
        try:
            counts = counts.filter(eval(dev_nd))
        except Exception as e:
            e = e
    if len(dn_room) > 0:
        dev_nd = ''
        first00_data = Device.objects.filter(room__id=dn_room)
        for i in first00_data:
            if dev_nd != '':
                dev_nd += ' | '
            dev_nd += 'Q(sno__icontains=\'' + str(i) + '\')'
        try:
            counts = counts.filter(eval(dev_nd))
        except Exception as e:
            e = e
    try:
        for i in counts:
            i = str(i)
            line[i] = json.loads(line_base(i))
        return JsonResponse({'status': True, 'data': line, 'error': str(e)})
    except Exception as e:
        e = e
        return JsonResponse({'status': False, 'error': str(e)})
