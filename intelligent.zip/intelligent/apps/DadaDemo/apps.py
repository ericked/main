from django.apps import AppConfig


class DadademoConfig(AppConfig):
    name = 'DadaDemo'
