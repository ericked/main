from django.conf.urls import url
from django.urls import path

from DadaDemo.views import views

urlpatterns = [
    url(r'^line/$', views.ChartView0.as_view(), name='demo_line'),
    url(r'^lines/$', views.ChartView1.as_view(), name='demo_lines'),
    url(r'^demo/$', views.IndexView.as_view(), name='demo_data'),
    url(r'^demos/$', views.IndexView0.as_view(), name='demo_data_s'),
    path('shown/', views.indst, name='demo_lisd')
]
