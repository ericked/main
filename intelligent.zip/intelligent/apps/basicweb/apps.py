from django.apps import AppConfig


class BasicwebConfig(AppConfig):
    name = 'apps.basicweb'
