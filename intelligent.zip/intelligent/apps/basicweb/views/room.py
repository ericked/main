from django.shortcuts import render
from basicweb.models import Room, Build
from django.http import JsonResponse
from django.db.models import Q


def index(request):
    return render(request, 'basic/room.html')


def list_values(request):
    page = int(request.POST.get('page', 0))
    limit = int(request.POST.get('limit', 0))
    q_str = request.POST.get('inputStr', '')
    objs = list(Room.objects.filter(Q(name__icontains=q_str) | Q(build__name__icontains=q_str)).values(
        'id', 'name', 'build__name', 'build_id'))
    objs_one_page = objs[(page-1) * limit: page * limit]
    res = {'code': 0, 'count': len(objs), 'data': objs_one_page}
    return JsonResponse(res)


def add_values(request):
    build = request.POST.get('build')
    room = request.POST.get('room')
    try:
        Room.objects.create(build_id=build, name=room)
        return JsonResponse({'status': True})
    except Exception as e:
        return JsonResponse({'status': False, 'error': '添加数据写入数据库出现异常， 具体原因：' + str(e)})


def edit_values(request):
    rec = request.POST
    try:
        obj = Room.objects.filter(id=rec.get('room_id')).first()
        obj.name = rec.get('room')
        obj.build = Build.objects.filter(id=rec.get('build')).first()
        obj.save()
        return JsonResponse({'status': True})
    except Exception as e:
        return JsonResponse({'status': False, 'error': '修改数据写入数据库出现异常， 具体原因：' + str(e)})


def del_values(request):
    id = request.POST.get('id')
    try:
        Room.objects.filter(id=id).first().delete()
        return JsonResponse({'status': True})
    except Exception as e:
        return JsonResponse({'status': False, 'error': '删除数据提交到数据库出现异常，具体原因：' + str(e)})


