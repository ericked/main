from django.shortcuts import render
from django.http import JsonResponse
from basicweb.models import Build

from utils import sqlhelper


def index(request):
    return render(request, 'basic/build.html')


def list_values(request):
    q_str = request.POST.get('queryStr', "")
    sql = """
    SELECT T3.id,T3.Name,  Count(*) as "Number"
    from
    (
    SELECT T1.id,T1.Name 
    from "Basic_Build" as T1 left JOIN "Basic_Room" BR ON T1.id = BR.build_id
        where T1.Name like '%s'
    ) AS T3
    GROUP BY T3.id,T3.Name
    """ % ('%' + q_str + '%')
    response = sqlhelper.get_db_data_dict(sql, ['id', 'name', 'number'])

    if response['status']:
        return JsonResponse({'status': True, 'data': response['data']})
    else:
        return JsonResponse({'status': False, 'error': response['error']})


def add_values(request):
    name = request.POST.get('name')

    try:
        Build.objects.create(name=name)
        return JsonResponse({'status': True})
    except Exception as e:
        return JsonResponse({'status': False, 'error': "写入数据库异常，具体原因：" + str(e)})


def edit_values(request):
    id = request.POST.get('id', '')
    name = request.POST.get('name', '')
    try:
        obj = Build.objects.get(id=id)
        obj.name = name
        obj.save()
        return JsonResponse({'status': True})
    except Exception as e:
        return JsonResponse({'status': False, 'error': '修改提交到数据库出现异常，具体原因：' + str(e)})


def del_values(request):
    id0 = request.POST.get('id')
    # 删除
    try:
        Build.objects.get(id=id0).delete()
        return JsonResponse({'status': True})
    except Exception as e:
        return JsonResponse({'status': False, 'error': '删除提交到数据库出现异常！具体原因：' + str(e)})
