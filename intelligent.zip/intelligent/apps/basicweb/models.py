from django.db import models


# Create your models here
class Build(models.Model):
    name = models.CharField(verbose_name='楼宇名称', max_length=100, unique=True, null=False)

    class Meta:
        managed = True
        app_label = "basicweb"
        db_table = "Basic_Build"
        verbose_name = "Build"
        verbose_name_plural = "Build"

    def __str__(self):
        return '%s' % self.name


class Room(models.Model):
    name = models.CharField(verbose_name='房间名称', max_length=100, unique=True, null=False)
    build = models.ForeignKey(verbose_name='所属楼宇', to=Build, on_delete=models.PROTECT)

    class Meta:
        managed = True
        app_label = "basicweb"
        db_table = "Basic_Room"
        verbose_name = "Room"
        verbose_name_plural = "Room"

    def __str__(self):
        return '%s' % self.name
