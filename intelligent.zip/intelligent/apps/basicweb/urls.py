from django.urls import path
from basicweb.views import build, room

urlpatterns = [
    path('build/', build.index, name="build"),
    path('room/', room.index, name="room"),
    path('build/list/', build.list_values, name="list_build"),
    path('build/add/', build.add_values, name="add_build"),
    path('build/edit/', build.edit_values, name="edit_build"),
    path('build/del/', build.del_values, name="del_build"),
    path('room/list/', room.list_values, name="list_room"),
    path('room/add/', room.add_values, name="add_room"),
    path('room/edit/', room.edit_values, name="edit_room"),
    path('room/del/', room.del_values, name="del_room"),

]
