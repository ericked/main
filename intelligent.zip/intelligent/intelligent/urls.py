from django.contrib import admin
from django.urls import path, include

urlpatterns = [
    path('admin/', admin.site.urls),
    path('basic/', include('basicweb.urls')),
    path('', include('mainweb.urls')),
    path('equip/', include('equipment.urls')),
    path('datadisplay/', include('datadisplay.urls')),
    path('captcha/', include('captcha.urls')),
    path('datademo/', include('DadaDemo.urls'))
]
